const theme = {
  primary: '#D6EE41',
  primaryVariant: '#C6D800',
  secondary: '#9A9A93',
  background: '#F6F8FA',
  accent: '#000000',
  nav: '#F1F2EC',
  white: '#FFFFFF',
};

export default theme;
