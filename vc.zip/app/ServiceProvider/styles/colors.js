const theme = {
  primary: '#D6EE41',
  primaryVariant: '#FFFFFF',
  secondary: '#FFFFFF',
  background: '#FFFFFF',
  accent: '#FFFFFF',
  nav: '#FFFFFF',
  white: '#FFFFFF',
};

export default theme;
